package Blanch;
//@author: Max Blanch
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.jsoup.Jsoup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class WebCrawler {
    private HashSet<String> linksURL; //stores links
    private ArrayList<String> outputBuilder; //gets lines for the eventual output (language, headers, links, etc.)
    private String startingURL = ""; //initial URL from the input, which must never change
    private int depth = 0;
    public WebCrawler(){ //WebCrawler constructor
        this.outputBuilder = new ArrayList<String>();
        this.linksURL = new HashSet<String>();
    }

    public void setInputLink(String URL){
        this.startingURL = URL; //initial URL is set
        this.outputBuilder.add(0,"input: <a>" + URL + "</a>\n"); //first line of output is added
    }

    public String getInputLink() { return this.startingURL; } //returns initial URL

    public String createReport(String URL, int maxDepth){ //biggest and "main" WebCrawler method, used to build the output arraylist
        if(!linksURL.contains(URL) && (depth < maxDepth)){ //
            try{
                Document htmlCode = Jsoup.connect(URL).get(); //gets the html code from given URL
                if(this.startingURL.isEmpty()){this.startingURL = URL;} //if starting URL is still empty, it is added
                getSourceLanguage(htmlCode, URL); //gets source language
                getHeaders(htmlCode, outputBuilder); //gets headers
                if(linksURL.add(URL) && !startingURL.equals(URL)) {
                    System.out.println("<br>--> link to <a>" + URL + "</a>");
                    outputBuilder.add("<br>--> link to <a>" + URL + "</a>\n");
                }
                Elements morePossibleLinks = htmlCode.select("a[href]"); //gets all <a> elements containing "href" attribute
                for(Element link : morePossibleLinks) {
                    this.depth++; //depth is increased
                    return createReport(link.attr("abs:href"), maxDepth); //recursive method
                }
            }catch(IOException e){
                System.out.println("<br>--> broken link <a> " + URL + "</a>");
                this.outputBuilder.add("<br>--> broken link <a> " + URL + "</a>\n"); //in case a link is not working, this line is added to the arraylist
                //note: the depth is not increased
            }
        }

        this.outputBuilder.add(2, "<br>summary: \n"); //adds line before the headers
        this.outputBuilder.add(1, "<br>depth: " + depth + "\n"); //adds depth right after the input line
        return outputToString(this.outputBuilder);

    }

    private String outputToString(ArrayList<String> outputBuilder){ //converts the ArrayList contents to String and returns said String
        String output = "";
        for(int index = 0; index < outputBuilder.size(); index++){
            output += outputBuilder.get(index);
        }
        return output;
    }

    private void getSourceLanguage(Document code, String URL) throws NullPointerException{
        if(this.startingURL.equals(URL)) {
            //if there's no specified language, throws NullPointerException
            try {
                this.outputBuilder.add("<br>source language: " + code.select("html[lang]").first().attr("lang") + "\n");
            } catch (NullPointerException e) {
                this.outputBuilder.add("<br>source language: not specified..");
            }
        }
    }

    private void getHeaders(Document code, ArrayList<String> outputBuilder){
        //get all headers and sets them all to their method based on name value (h1, h2, h3, h4, h5, h6)
        Elements hTags = code.select("h1, h2, h3, h4, h5, h6");
        getSelectedHeaders(hTags.select("h1"), outputBuilder);
        getSelectedHeaders(hTags.select("h2"), outputBuilder);
        getSelectedHeaders(hTags.select("h3"), outputBuilder);
        getSelectedHeaders(hTags.select("h4"), outputBuilder);
        getSelectedHeaders(hTags.select("h5"), outputBuilder);
        getSelectedHeaders(hTags.select("h6"), outputBuilder);
    }

    private void getSelectedHeaders(Elements headers, ArrayList<String> outputBuilder){
        //for each header, depending on the hierarchy, a number of "#" is given and the value of header
        for(Element header: headers){
            if(header.is("h1")){
                outputBuilder.add("#" + header.attr("h1") +"\n");
            }else if(header.is("h2")){
                outputBuilder.add("##" + header.attr("abs:h2") +"\n");
            }else if(header.is("h3")){
                outputBuilder.add("###" + header.attr("abs:h3") +"\n");
            }else if(header.is("h4")){
                outputBuilder.add("####" + header.attr("abs:h4") +"\n");
            }else if(header.is("h5")){
                outputBuilder.add("#####" + header.attr("abs:h5") +"\n");
            }else if(header.is("h6")){
                outputBuilder.add("######" + header.attr("abs:h6") +"\n");
            }
        }
    }

    public void createOutputFile(String report){
        try{
            File reportFile = new File("report.md");
            if(reportFile.createNewFile()){ //if file doesn't exist, creates a new file and writes the report on it.
                System.out.println("New file created");
                writeInFile(reportFile, report); //writes report on file
            }else { //if file exists already, it's deleted and the mathod is called again, recursively.
                System.out.println("File substitute");
                deleteFile(reportFile);
                createOutputFile(report);
            }
        }catch(IOException e){ //in case there's a problem of any kind in regards to Input and Output
            System.out.println("An error occurred.");
            e.printStackTrace(); //prints the error
        }
    }

    private void deleteFile(File reportFile){ //method is used when the reportFile exists already.
        File fileToBeDeleted = reportFile;
        if(fileToBeDeleted.delete()){ //file is deleted
            System.out.println("Old File deleted");
        }else{
            System.out.println("Failed to delete file");
        }

        //since there's no Input or Output of any kind, there's no need to check for errors using try{...}catch(...){...}
    }

    public void writeInFile(File reportFile, String report){ //writes report on file
        try{
            FileWriter fileToBeWritten = new FileWriter(reportFile.getName());
            fileToBeWritten.write(report);
            fileToBeWritten.close();
            System.out.println("File written");
        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public String getInputLink(Scanner inputLink){
        return inputLink.next();
    } //input linkn

    public int getInputMaxDepth(Scanner inputDepth){
        return inputDepth.nextInt();
    } //input maxDepth
}
