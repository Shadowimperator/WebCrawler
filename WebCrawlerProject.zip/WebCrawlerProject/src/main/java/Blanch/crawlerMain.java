package Blanch;

import java.util.Scanner;
//project's main file
public class crawlerMain {
    public static void main(String args[]){
        StringBuilder outputBuilder = new StringBuilder(); //StringBuilder used to build the output to eventually pass
        WebCrawler webCrawler = new WebCrawler(); //Creation of object webCrawler of type WebCrawler
        Scanner inputs = new Scanner(System.in); //inputs will be used to get inputs from the user

        System.out.println("Enter a link you'd like to crawl: ");
        String link = webCrawler.getInputLink(inputs); //user input is returned as value of variable link
        System.out.println("\nHow deep you want to crawl?");
        int maxDepth = webCrawler.getInputMaxDepth(inputs); //user input is returned as value of value maxDepth

        webCrawler.setInputLink(link); //seting of initial input
        outputBuilder.append(webCrawler.createReport(link, maxDepth)); //gets all remaining links and headers from input link

        webCrawler.createOutputFile(outputBuilder.toString()); //creates the report.md file
    }
}
