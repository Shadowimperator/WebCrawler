//@author: Max Blanch
import Blanch.WebCrawler;
import org.junit.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WebCrawlerTests {

    private static String testingLink = "https://en.wikipedia.org/wiki/Sun";
    private static WebCrawler webCrawlerSample = new WebCrawler();
    private static WebCrawler webCrawlerTrial = new WebCrawler();
    private static int maxDepth = 5;
    private static String reportSample = webCrawlerSample.createReport(testingLink, maxDepth);


    @Before
    void setUp(){
        webCrawlerSample.setInputLink(testingLink);
        webCrawlerTrial.setInputLink(testingLink);
        reportSample = webCrawlerSample.createReport(testingLink, maxDepth);
    }

    @Test
    public void getInputTesting(){
        assertEquals(testingLink, webCrawlerTrial.getInputLink(), "Sample and test links should be the same");
    }

    @Test
    public void reportCreationTesting() throws NullPointerException{
        assertEquals(reportSample, webCrawlerTrial.createReport(testingLink, maxDepth), "Creation of report should work");
    }
}
