package Blanch;
//@author: Max Blanch
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.jsoup.Jsoup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class WebCrawler {
    private HashSet<String> linksURL;
    private ArrayList<String> outputBuilder;
    private String startingURL = "";
    //private static final int MAX_DEPTH = 2;

    public WebCrawler(){
        this.outputBuilder = new ArrayList<String>();
        this.linksURL = new HashSet<String>();
    }

    public void setInputLink(String URL){
        this.startingURL = URL;
        this.outputBuilder.add(0,"input: <a>" + URL + "</a>\n");
    }

    public String getInputLink() { return this.startingURL; }

    public String createReport(String URL, int depth, int maxDepth){
        if(!linksURL.contains(URL) && (depth < maxDepth)){
            try{
                Document htmlCode = Jsoup.connect(URL).get();
                if(this.startingURL.isEmpty()){this.startingURL = URL;}
                if(this.startingURL.equals(URL)) {
                    try {
                        this.outputBuilder.add("<br>source language: " + getSourceLanguage(htmlCode) + "\n");
                    } catch (NullPointerException e) {
                        this.outputBuilder.add("<br>source language: not specified..");
                    }
                }
                getHeaders(htmlCode, outputBuilder);
                if(linksURL.add(URL) && !startingURL.equals(URL)) {
                    System.out.println("<br>--> link to <a>" + URL + "</a>");
                    outputBuilder.add("<br>--> link to <a>" + URL + "</a>\n");
                }
                Elements morePossibleLinks = htmlCode.select("a[href]");
                for(Element link : morePossibleLinks) return createReport(link.attr("abs:href"), depth++, maxDepth);
            }catch(IOException e){
                System.out.println("<br>--> broken link <a> " + URL + "</a>");
                this.outputBuilder.add("<br>--> broken link <a> " + URL + "</a>\n");
            }
        }

        this.outputBuilder.add(2, "<br>summary: \n");
        this.outputBuilder.add(1, "<br>depth: " + depth + "\n");
        return outputToString(this.outputBuilder);

    }

    private String outputToString(ArrayList<String> outputBuilder){
        String output = "";
        for(int index = 0; index < outputBuilder.size(); index++){
            output += outputBuilder.get(index);
        }
        return output;
    }

    private String getSourceLanguage(Document code) throws NullPointerException{
        if(code.select("html[lang]").isEmpty()){
            return "no language specified";
        }else{
            return code.select("html[lang]").first().attr("lang");
        }

    }

    private void getHeaders(Document code, ArrayList<String> outputBuilder){
        Elements hTags = code.select("h1, h2, h3, h4, h5, h6");
        getSelectedHeaders(hTags.select("h1"), outputBuilder);
        getSelectedHeaders(hTags.select("h2"), outputBuilder);
        getSelectedHeaders(hTags.select("h3"), outputBuilder);
        getSelectedHeaders(hTags.select("h4"), outputBuilder);
        getSelectedHeaders(hTags.select("h5"), outputBuilder);
        getSelectedHeaders(hTags.select("h6"), outputBuilder);
    }

    private void getSelectedHeaders(Elements headers, ArrayList<String> outputBuilder){
        for(Element header: headers){
            if(header.is("h1")){
                outputBuilder.add("#" + header.attr("h1") +"\n");
            }else if(header.is("h2")){
                outputBuilder.add("##" + header.attr("abs:h2") +"\n");
            }else if(header.is("h3")){
                outputBuilder.add("###" + header.attr("abs:h3") +"\n");
            }else if(header.is("h4")){
                outputBuilder.add("####" + header.attr("abs:h4") +"\n");
            }else if(header.is("h5")){
                outputBuilder.add("#####" + header.attr("abs:h5") +"\n");
            }else if(header.is("h6")){
                outputBuilder.add("######" + header.attr("abs:h6") +"\n");
            }
        }
    }

    public void createOutputFile(String report){
        try{
            File reportFile = new File("report.md");
            if(reportFile.createNewFile()){
                System.out.println("New file created");
                writeInFile(reportFile, report);
            }else {
                System.out.println("File substitute");
                deleteFile(reportFile);
                createOutputFile(report);
            }
        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void deleteFile(File reportFile){
        File fileToBeDeleted = reportFile;
        if(fileToBeDeleted.delete()){
            System.out.println("Old File deleted");
        }else{
            System.out.println("Failed to delete file");
        }
    }

    public void writeInFile(File reportFile, String report){
        try{
            FileWriter fileToBeWritten = new FileWriter(reportFile.getName());
            fileToBeWritten.write(report);
            fileToBeWritten.close();
            System.out.println("File written");
        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public String getInputLink(Scanner inputLink){
        return inputLink.next();
    }

    public int getInputMaxDepth(Scanner inputDepth){
        return inputDepth.nextInt();
    }
}
