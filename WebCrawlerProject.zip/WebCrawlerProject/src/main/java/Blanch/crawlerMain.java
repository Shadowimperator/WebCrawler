package Blanch;

import java.util.Scanner;

public class crawlerMain {
    public static void main(String args[]){
        StringBuilder outputBuilder = new StringBuilder();
        WebCrawler webCrawler = new WebCrawler();
        Scanner inputs = new Scanner(System.in);

        System.out.println("Enter a link you'd like to crawl: ");
        String link = webCrawler.getInputLink(inputs);
        System.out.println("\nHow deep you want to crawl?");
        int maxDepth = webCrawler.getInputMaxDepth(inputs);

        webCrawler.setInputLink(link);
        outputBuilder.append(webCrawler.createReport(link, 0, maxDepth));

        webCrawler.createOutputFile(outputBuilder.toString());
    }
}
